#ifndef BOOST_VERSION_NDK_HPP
#define BOOST_VERSION_NDK_HPP

//The version of the NDK used to build boost
 #define BOOST_BUILT_WITH_NDK_VERSION  "21.0.6113669" 

#endif
